<?
# LOGO EDITS .
	$whatsapp = get_option('whatsapp_number');
	echo '<footer>';
		echo '<div class="--YC-footer--">';
			echo '<div class="container">';
				echo '<div class="Yc--footer">';
					# menus area
					echo '<div class="footer-left">';
						# bottom area
						echo '<div class="footer-bottom-menus">';
							echo '<div class="all--footer--menu--in">';
								# FIRST LOGO SECTION .
								$hide_footer__first__slice = get_option('hide_footer__first__slice');
								if( empty( $hide_footer__first__slice ) ){


									echo '<div class="-footer-widgets-single -current-widgets-logo">';

										# LOGO FOOTER .
											$hide_logo_footer = get_option('hide_logo_footer');
											if( empty( $hide_logo_footer ) ){
												$footer__logo = get_option( 'footer__logo' );
												$footer__logo = ( ( is_array( $footer__logo ) ) ) ? $footer__logo : array();
												if( empty( $footer__logo ) || empty( $footer__logo ) && ( !isset( $footer__logo['logo__mode'] ) || ( isset( $footer__logo['logo__mode'] ) && isset( $footer__logo[ $footer__logo['logo__mode'] ] ) ) ) ) $footer__logo = array( 'logo__mode'=>'Text','logo__mode'=>array('logo_Text'=>'YOUR{%COLOR%}') );
												if( isset( $footer__logo['logo__mode'] ) && $footer__logo['logo__mode'] == 'Image' && isset( $footer__logo[ $footer__logo['logo__mode'] ] ) && isset( $footer__logo[ $footer__logo['logo__mode'] ]['image_logo'] ) && isset( $footer__logo[ $footer__logo['logo__mode'] ]['image_logo_id'] ) ){
													$footer__logo[ $footer__logo['logo__mode'] ]['header__alt'] = ( ( isset( $footer__logo[ $footer__logo['logo__mode'] ]['header__alt'] ) ) ) ? $footer__logo[ $footer__logo['logo__mode'] ]['header__alt'] : get_bloginfo('name');
													echo '<div class="-footer-site-logo --logo-'.$footer__logo['logo__mode'].'">';
													    echo '<a href="'.home_url().'" title="'.$footer__logo[ $footer__logo['logo__mode'] ]['header__alt'].'">';
													        echo YC_get_attachment(
													        	array(
														            'alt' =>$footer__logo[ $footer__logo['logo__mode'] ]['header__alt'],
														            'id'=>$footer__logo[ $footer__logo['logo__mode'] ]['image_logo_id'],
														            'alt'=>$footer__logo[ $footer__logo['logo__mode'] ]['header__alt'],
														            'size'=>'footer_sizelogo',
														        )
														    );
													    echo '</a>';
													echo '</div>';
												}else if( isset( $footer__logo['logo__mode'] ) &&  $footer__logo['logo__mode'] == 'Text' ){

													$footer__logo[ $footer__logo['logo__mode'] ]['header__alt'] = ( ( isset( $footer__logo[ $footer__logo['logo__mode'] ]['header__alt'] ) ) ) ? $footer__logo[ $footer__logo['logo__mode'] ]['header__alt'] : get_bloginfo('name');

													if( isset( $footer__logo[ $footer__logo['logo__mode'] ]['logo_Text'] ) && strpos( $footer__logo[ $footer__logo['logo__mode'] ]['logo_Text'],'{%') !== FALSE && strpos( $footer__logo[ $footer__logo['logo__mode'] ]['logo_Text'],'%}') !== FALSE ){
														$footer__logo[ $footer__logo['logo__mode'] ]['logo_Text'] = "<span class='first-logo-word'>{$footer__logo[ $footer__logo['logo__mode'] ]['logo_Text']}";
														$footer__logo[ $footer__logo['logo__mode'] ]['logo_Text'] = str_replace('{%','</span><strong class="second-logo-word">',$footer__logo[ $footer__logo['logo__mode'] ]['logo_Text']);
														$footer__logo[ $footer__logo['logo__mode'] ]['logo_Text'] = str_replace('%}','</strong>',$footer__logo[ $footer__logo['logo__mode'] ]['logo_Text']);
													}
													echo '<div class="-footer-site-logo --logo-'.$footer__logo['logo__mode'].'">';
														echo '<a href="'.home_url().'" title="'.$footer__logo[ $footer__logo['logo__mode'] ]['header__alt'].'">'.$footer__logo[ $footer__logo['logo__mode'] ]['logo_Text'].'</a>';
													echo '</div>';
												}									
											}

										# FOOTER DESCRIPTION .	
											$hide_description_footer = get_option('hide_description_footer');
											if( empty( $hide_description_footer ) )	$footer__content = get_option('footer__content');
											if( empty( $hide_description_footer ) && !empty( $footer__content ) ) echo '<div class="-footer-p-content">'.$footer__content.'</div>';


										# HIDE SOCIAL EDITS .
											$social_footer = get_option( 'social_footer' );
											if( empty( $social_footer ) ) {
												$social_footer_list = get_option('social_footer_list');
												$social_footer_list = ( ( is_array( $social_footer_list ) ) ) ? $social_footer_list : array();
												if( !empty( $social_footer_list ) ){
													$SocialIcon = array(
														'facebook'=>'<i class="fab fa-facebook-f"></i>',
														'twitter'=>'<i class="fab fa-twitter"></i>',
														'telegram'=>'<i class="fa-brands fa-telegram"></i>',
														'youtube'=>'<i class="fab fa-youtube"></i>',
														'linkedin'=>'<i class="fab fa-linkedin-in"></i>',
														'instagram'=>'<i class="fab fa-instagram"></i>',
													);
													echo '<div class="-row-shares-items">';
														foreach ( $social_footer_list as $social__item ) {
															$social_value = get_option($social__item);
															if( !empty($social_value) ) {
																echo'<a class="'.$social__item.'" title="'.$social__item.'" target="_blank" href="'.$social_value.'">'.$SocialIcon[ $social__item ].'</a>';
															}
														}
													echo '</div>';										
												}
											}

									echo '</div>';
								}
							

								# SECOND FOOTER SECTION .
								$hide_footer__first_menu = get_option('hide_footer__first_menu');
								if( empty( $hide_footer__first_menu ) ) $footer__first_menu = get_option('footer__first_menu');

								if( empty( $hide_footer__first_menu ) && !empty( $footer__first_menu ) ){
									echo '<div class="-footer-widgets-single -current-widgets-menu1">';
										$footer__title_first_menu = get_option('footer__title_first_menu');
										echo '<div class="-footer-widgets-title">';
											echo ''.( ( !empty( $footer__title_first_menu ) ) ? $footer__title_first_menu : '' ).'';
										echo '</div>';
										$NavList = wp_get_nav_menu_items($footer__first_menu);

										echo '<ul class="-footer-widgets-links">';
											foreach ( is_array( $NavList ) ? $NavList : array() as $pages) {
												echo '<li>';
													echo '<a href="'.$pages->url.'" class="activable">'.$pages->title.'</a>';
												echo '</li>';
											}
										echo '</ul>';
									echo '</div>';
								}

								# THIRD FOOTER SECTION .
								$hide_footer__second_menu = get_option('hide_footer__second_menu');
								if( empty( $hide_footer__second_menu ) ) $footer__second_menu = get_option('footer__second_menu');	
													
								if( empty( $hide_footer__second_menu ) && !empty( $footer__second_menu ) ){
									echo '<div class="-footer-widgets-single -current-widgets-menu2">';

										$footer__title_second_menu = get_option('footer__title_second_menu');
										echo '<div class="-footer-widgets-title">';
											echo ''.( ( !empty( $footer__title_second_menu ) ) ? $footer__title_second_menu : '' ).'';
										echo '</div>';

										$NavList = wp_get_nav_menu_items($footer__second_menu);

										echo '<ul class="-footer-widgets-links">';
											foreach ( is_array( $NavList ) ? $NavList : array() as $pages) {
												echo '<li>';
													echo '<a href="'.$pages->url.'" class="activable">'.$pages->title.'</a>';
												echo '</li>';
											}
										echo '</ul>';
									echo '</div>';
								}

								# FOUTH FOOTER SECTION .
								$hide_contact__footer = get_option('hide_contact__footer');
								if( empty( $hide_contact__footer ) ) $contact_footer_list = get_option('contact_footer_list');

								if( empty( $hide_contact__footer ) && !empty( $contact_footer_list ) ){
									$contact_footer_list = ( ( is_array( $contact_footer_list ) ) ) ? $contact_footer_list : array();

									$footer__title_contact_menu = get_option('footer__title_contact_menu');
									echo '<div class="-footer-widgets-single -current-widgets-contact">';

										echo '<div class="-footer-widgets-title">';
											echo ''.( ( !empty( $footer__title_contact_menu ) ) ? $footer__title_contact_menu : 'تواصل معنا' ).'';
										echo '</div>';

										echo '<div class="-company-contact-minibox">';
											$SocialIcon = array(
												'phonenumber'=>'<i class="fa-solid fa-mobile-screen-button"></i>',
												'company__adress'=>'<i class="fa-solid fa-map-location-dot"></i>',
												'whatsapp'=>'<i class="fa-brands fa-whatsapp"></i>',
												'company__mail'=>'<i class="fa-solid fa-envelope"></i>',
											);
												
											foreach ( $contact_footer_list as $social__item ) {
												$social_value = get_option($social__item);
												if( !empty($social_value) ) {
													$URL__value = $social_value;
													$Name__value = $social_value;
													if( $social__item == 'whatsapp_number' ) {
														$URL__value = "https://wa.me/{$social_value}";
														$Name__value = 'تواصل عبر الواتساب ';
														$social__item = 'whatsapp';
													}
													if( $social__item == 'phonenumber' ) {
														$URL__value = "tel:{$social_value}";
														$Name__value = $social_value;
													}
													if( $social__item == 'company__mail' || $social__item == 'company__adress' ) {
														$Name__value = $social_value;
														$URL__value = get_option("footer__{$social__item}_url");
													}
													echo '<div class="'.$social__item.'">';
														echo ( ( !empty( $URL__value ) ) ) ? '<a target="_blank" href="'.$URL__value.'"  title="'.$Name__value.'">' : '';
															echo $SocialIcon[ $social__item ];
															echo '<span>'.$Name__value.'</span>';
														echo ( ( !empty( $URL__value ) ) ) ? '</a>' : '';
													echo '</div>';
												}
											}

										echo '</div>';
									echo '</div>';
								}


								# FOOTER MAP .	
								$hide_footer__map = get_option('hide_footer__map');
								if( empty( $hide_footer__map ) ) {
									$company__map_code = get_option('company__map_code');
									$company__map_title = get_option('company__map_title');
								}

								if( empty( $hide_footer__map ) && !empty( $company__map_code ) && !empty( $company__map_title ) ){

									if( !empty( $company__map_title ) ) $company__map_code = str_replace('src=','title="'.$company__map_title.'" src=',$company__map_code);
									$company__map_code = str_replace('src=', "data-loader-src=", $company__map_code);

									echo '<div class="-footer-widgets-single -current-widgets-maps">';
										echo '<div class="--Inner--footer--sit-map">'.$company__map_code.'</div>';
									echo '</div>';
								}
							echo '</div>';
						echo '</div>';
						# end area

					echo '</div>';
					# end menu area

				echo '</div>';
			echo '</div>';
			echo '<div class="-current-widgets-payments">';
				echo '<div class="container">';

					echo '<footer-bottom>';
						$copyrights = get_option('copyrights');
						if( !empty( $copyrights ) ){
							if( strpos( $copyrights,'{%YEAR%}' ) !== FALSE ) {
								$currentYear = date('Y');
								$copyrights = str_replace('{%YEAR%}', $currentYear, $copyrights);
							}
							echo '<p class="copyrights">'.$copyrights.'</p>';
						}
				// 		echo'<div class="yourcolor--copyright">';
				// 			echo '<p>تصميم وبرمجه <a target="_blank" rel="noopener" href="https://yourcolor.net"><img width="96" height="16" data-loader-src="'.$CurrentURL.'/yourcolor.png" alt="Yourcolor Workshop"/></a></p>';
				// 		echo'</div>';
					echo '</footer-bottom>';


				echo '</div>';

			echo '</div>';		
		echo '</div>';
	echo '</footer>';

	// btn contact
	if( is_single() || is_page() ){
		global $post;
		$phonenumber = get_post_meta( $post->ID,'phone_number',true );
		if( empty( $phonenumber ) ) $phonenumber = get_option('phonenumber');

		$whatsapp_number = get_post_meta( $post->ID,'whatsapp_number',true );
		if( empty( $whatsapp_number ) ) $whatsapp_number = get_option('whatsapp_number');
	}else{
		$phonenumber = get_option('phonenumber');
		$whatsapp_number = get_option('whatsapp_number');
	}

	echo '<div class ="btn-fixed-bh">';
		echo '<div class="--yourcolor--button--phones --YourColor--phone-button">';
			echo'<a href="tel:'.$phonenumber.'" aria-label="اتصل بنا :" data-call="Phone" data-tooltip="اتصل بنا " data-position="top">';
				echo '<div class="footer-header">';
					echo '<i class="fa-solid fa-phone"></i>';
					echo '</div>';
				echo'</a>';
		echo'</div>';
		echo'<div class="--yourcolor--button--phones --YourColor--whatsapp-button">';
			echo '<a href="https://wa.me/'.$whatsapp_number.'" target="_blank" aria-label="  الواتساب  " data-call="whatsapp" data-tooltip="تواصل عبر واتساب" data-position="top">';
				echo '<div class="footer-header">';
					echo '<i class="fa-brands fa-whatsapp"></i>';
				echo '</div>';
			echo '</a>';
		echo'</div>';
	
	echo'</div>';

echo '</root>';

$HTML_otput = ob_get_clean();
$SVG_List = array();
if( strpos( $HTML_otput , 'data-svg-loaders="') !== FALSE ){
	$SVGLoader = explode('data-svg-loaders="', $HTML_otput);unset($SVGLoader[0]);
	foreach ( $SVGLoader as $w => $ee) {
		$SvgName = explode('"', $ee)[0];
		if( !isset( $SVG_List[ $SvgName ] ) ){
			$SVG_List[ $SvgName ] = SVGIcon($SvgName);
		}
	}
}

echo $HTML_otput;

# STYLE CSS
$Css_List = array();
if(isset($Styles)){
	foreach ($Styles as $skey => $meky) {
		$Css_List[$skey] = $this->StylesURL.$meky.'?v='.rand();
	}
}

if( isset($_GET['ajax']) ) {

	$output = ob_get_clean();
	$title = wp_title( '|', false, 'right' );
	$CurrentURL = $this->GetCurrentURL();
	$CurrentURL = remove_query_arg( 'ajax', $CurrentURL );
	if( is_search() ) {
		$search_query = get_search_query();
		$CurrentURL = home_url('/search/'.str_replace(' ', '-', $search_query).'/');
	}
	$array = array(
		"output"	=> $output,
		"title"		=> $title,
		"url"		=> $CurrentURL,
		"Css_List" => $Css_List,
		"SVG_List" => $SVG_List,
	);
	$json = safe_json_encode($array);
	footer('Content-Length: '.strlen($json)); // HERE IS THE PROBLEM
	footer('Content-type: application/json');
	echo $json;
}else {
	###
	global $current_user;
	###
	$TempDIR = $this->TempURL;
	echo '<script type="text/javascript">';
		echo "var WPAdminAjax = '".admin_url('admin-ajax.php')."';";
		echo "var AdminAjax = '".home_url('/ajaxcenter/')."';";
		echo "var HomeURL = '".home_url()."';";
		echo "var TmpDIR = '".get_template_directory_uri()."';";
		echo "var ISMobile = ".((wp_is_mobile()) ? 'true' : 'false').";";
		echo "var IsSpeed = ".( ( IsSpeed() != false ) ? 'true' : 'false').";";
		echo "var IsHome = ".((is_home()) ? 'true' : 'false').";";
		echo "var IsSingle = ".(is_single() ? 'true' : 'false').";";

		echo "var Currentuser_ID = '".$current_user->ID."';";
		echo "var Currentuser_first_name = '".$current_user->first_name."';";
		echo "var Currentuser_last_name = '".$current_user->last_name."';";
		echo "var Currentuser_display_name = '".$current_user->display_name."';";
		echo "var Currentuser_email = '".$current_user->user_email."';";
		echo "var Currentuser_Logged = true;";
		echo "var SVG_List = ".json_encode($SVG_List).";";
		echo 'function onTouchStart() {}document.addEventListener(\'touchstart\', onTouchStart, {passive: true});';
	echo '</script>';
	
	if( IsSpeed() == false && ( is_single() || is_page() || ( isset( $Widgets__list ) && in_array( 'works_v1',$Widgets__list ) ) ) ){
		echo "<script id='rendered-js' type='module'>";
			echo "import PhotoSwipeLightbox from 'https://unpkg.com/photoswipe/dist/photoswipe-lightbox.esm.js';";
			echo "if( $( '[pswp]' ).length ){";
				echo "var lightbox = new PhotoSwipeLightbox({";
				  echo "gallery: '[pswp]',";
				  echo "children: 'a',";
				  echo "initialZoomLevel: 'fit',";
				  echo "secondaryZoomLevel: 1,";
				  echo "maxZoomLevel: 5,";
				  echo "pswpModule: () => import('https://unpkg.com/photoswipe') });";

				  echo "function LightboxInit() {";
				  	echo "lightbox.init();";
				  echo "}";
				  echo "LightboxInit();";
				echo "$( document ).ajaxComplete(function() {";
					echo "LightboxInit();";
				echo "});";
			echo "}";

			echo "if( $( '[data-gallery-popover]' ).length ){";
				echo "const loadGalleryElements = document.querySelectorAll('[data-gallery-popover]');";
				echo "const lightboxes = [];";

				echo "loadGalleryElements.forEach((element, index) => {";
				  	echo "const argumentsBase64 = element.getAttribute('data-gallery-popover');";
				  	echo "const decodedArguments = atob(argumentsBase64);";
				  	echo "const parsedArguments = JSON.parse(decodedArguments);";

					echo "const options = {";
					  	echo "dataSource: parsedArguments,";
					  	echo "showHideAnimationType: 'none',";
					  	echo "pswpModule: () => import('https://unpkg.com/photoswipe'),";
					echo "};";

				  	//echo "options.dataSource.push(...parsedArguments);";

				  	echo "const lightbox = new PhotoSwipeLightbox(options);";
				  	echo "lightbox.init();";
				  	//echo "lightboxes.push(lightbox);";

				  	echo "element.onclick = () => {";
				    	echo "lightbox.loadAndOpen(index);";
				  	echo "};";
				echo "});";
			echo "}";

	    echo "</script>";
	}

	wp_footer();
	echo '<div class="GotoTop"><i class="fa-light fa-arrow-up"></i></div>';
	
	echo '</body>';
	echo '</html>';
}