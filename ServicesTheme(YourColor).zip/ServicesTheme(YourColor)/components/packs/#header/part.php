<?
ob_start();

if( !isset( $bodyClass ) ) $bodyClass = '';
# INTRO OPTIONS .

$site_color = get_option('site_color'); 
$text_Color = get_option('text_Color');

if( !isset($_GET['ajax']) ) {
	echo '<!DOCTYPE html>';
	echo '<html lang="ar" dir="rtl">';
	echo '<head>';
		echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
		echo '<meta charset="utf-8">';
		$hide__description_show = get_option('hide__description_show');
		if( empty( $hide__description_show ) || empty( $hide__description_show ) ) {
			echo'<meta name="description" content="'.get_bloginfo("name").'">';
		}


		//
		$hide__theme_seo = get_option('hide__theme_seo');
		if( empty( $hide__theme_seo ) ) (new ThemeSeo)->Title();

		do_action('BeforeWPHead');

		echo ( ( IsSpeed() == false ) ) ? '<link rel="stylesheet" media="all" type="text/css" data-loader-href="https://site-assets.fontawesome.com/releases/v6.5.1/css/all.css" />' : '';
		echo ( ( IsSpeed() == false && ( is_single() || is_page() || ( isset( $Widgets__list ) && in_array( 'works_v1',$Widgets__list ) ) ) ) ) ? '<link rel="stylesheet" data-loader-href="https://unpkg.com/photoswipe@5.2.2/dist/photoswipe.css">' : '';

		if( isset( $HeadCode ) && !empty( $HeadCode ) ){
			echo $HeadCode;
		}else{
			echo get_option('header___codes');
		}
		
		wp_head();

		$Styles['forms'] = 'forms.css';

       	$ips = ( is_array( get_option( "open_css" ) ) ) ? get_option( "open_css" ) : array();
		if( isset($_GET['open__css']) ) {
	       $ips[$_SERVER['REMOTE_ADDR']] = true;
	       update_option("open_css", $ips);
		}

		if( isset( $ips[ $_SERVER['REMOTE_ADDR'] ]) ) {
			echo '<style>';
				$this->Part('fonts');
			echo '</style>';
			if(isset($Styles)){
				foreach ($Styles as $skey => $meky) {
					echo '<link rel="stylesheet" data-style-ajax="'.$skey.'" type="text/css" href="'.$this->StylesURL.$meky.'?v='.rand().'" />';
				}
			}

			echo '<link rel="stylesheet" data-style-ajax="main" type="text/css" href="'.$this->StylesURL.'main.css?v='.rand().'" />';
			echo '<link rel="stylesheet" data-style-ajax="hover" type="text/css" href="'.$this->StylesURL.'hover.css?v='.rand().'" />';
			echo '<link rel="stylesheet" data-style-ajax="responsive" type="text/css" href="'.$this->StylesURL.'responsive.css?v='.rand().'" />';
		}else{
		    echo '<style>';
				$this->Part('fonts');
				if(isset($Styles)){
					foreach ($Styles as $skey => $meky) {
		    			require ($this->StylesPath.$meky);
					}
				}
		    	require ($this->StylesPath."/main.css");
		    	require ($this->StylesPath."/hover.css");
		    	require ($this->StylesPath."/responsive.css");
		    echo '</style>';			
		}

		do_action('AfterWPHead');
		if( !empty( get_option('favicon') ) ) {
			echo '<link rel="shortcut icon" type="image/png" href="'.get_option('favicon').'">';
		}

		echo '<meta name="apple-mobile-web-app-title" content="'.get_bloginfo('name').'">';
		echo '<meta http-equiv="Cache-control" content="public">';
		echo '<meta name="application-name" content="'.get_bloginfo('name').'">';
		echo '<link rel="preload" as="font">';
		echo '<meta name="msapplication-TileColor" content="#a03576">';
		//
		echo '<style>';
			echo 'body { ';
				echo ( ( !empty( $site_color ) ) ) ? '--uicolor:'.$site_color.';' : '';
				echo ( ( !empty( $text_Color ) ) ) ? '--primary-text:'.$text_Color.';' : '';
			echo '}';
		echo '</style>';
	echo '</head>';
	echo '<body mode="light" class="before-start '.$bodyClass.'">';
	do_action('yc_hook_body_start');
}

# LOGO EDITS .
	$logo__data = get_option( 'logo__data' );
	$logo__data = ( ( is_array( $logo__data ) ) ) ? $logo__data : array();
	if( empty( $logo__data ) || empty( $logo__data ) && ( !isset( $logo__data['logo__mode'] ) || ( isset( $logo__data['logo__mode'] ) && isset( $logo__data[ $logo__data['logo__mode'] ] ) ) ) ) 
		$logo__data = array( 'logo__mode'=>'Text','logo__mode'=>array('logo_Text'=>'YOUR{%COLOR%}') );

# SEARCHING AREA EDITS .
	$hide_search = get_option( 'hide_search' );
	if( empty( $hide_search ) ) {
		$search_placeholder = get_option('search_placeholder');
		$search_title = get_option('search_title');
		$search__Button = get_option('search__Button');
		$searchButtonType = 'icon';

	}
		if( !empty( $search__Button ) && isset( $search__Button['button_mode'] ) && $search__Button['button_mode'] == 'Text' && isset( $search__Button[ $search__Button['button_mode'] ] ) ) {
			$Text_search_button = $search__Button[ $search__Button['button_mode'] ]['logo_Text'];
			$searchButtonType = $search__Button['button_mode'];
		}else{
			$Text_search_button = '<i class="fa-light fa-magnifying-glass"></i>';
		}
# HIDE SOCIAL EDITS .
$hide_social_header = get_option( 'hide_social_header' );
if( empty( $hide_social_header ) ) {
	$social_header_list = get_option('social_header_list');
	$social_header_list = ( ( is_array( $social_header_list ) ) ) ? $social_header_list : array();		
}
$contact_icon = get_option('contact_icon');
$contact_title = get_option('contact_title');
$contact_number = get_option('contact_number');
echo '<root>';
	echo '<header class="fixedintro">';
		echo '<div class="-Header-Fix">';
			echo '<div class="container">';

				echo '<div class="-mobile-menu-button background">';
				  	echo '<div class="menu__icon">';
				    	echo '<span></span>';
				    	echo '<span></span>';
				    	echo '<span></span>';
				  	echo '</div>';
				echo '</div>';
				# SITE LOGO	
				if( isset( $logo__data['logo__mode'] ) && $logo__data['logo__mode'] == 'Image' && isset( $logo__data[ $logo__data['logo__mode'] ] ) && isset( $logo__data[ $logo__data['logo__mode'] ]['image_logo'] ) && isset( $logo__data[ $logo__data['logo__mode'] ]['image_logo_id'] ) ){
					$logo__data[ $logo__data['logo__mode'] ]['header__alt'] = ( ( isset( $logo__data[ $logo__data['logo__mode'] ]['header__alt'] ) ) ) ? $logo__data[ $logo__data['logo__mode'] ]['header__alt'] : get_bloginfo('name');
					echo '<div class="-site-logo --logo-'.$logo__data['logo__mode'].' '.( ( empty( $hide_social_header ) || empty( $hide_search ) ) ? ' active':'').'">';					
					    echo '<a href="'.home_url().'" title="'.$logo__data[ $logo__data['logo__mode'] ]['header__alt'].'">';
					        echo YC_get_attachment(
					        	array(
						            'alt' =>$logo__data[ $logo__data['logo__mode'] ]['header__alt'],
						            'id'=>$logo__data[ $logo__data['logo__mode'] ]['image_logo_id'],
						            'alt'=>$logo__data[ $logo__data['logo__mode'] ]['header__alt'],
						            'size'=>'logo__size',
						        )
						    );
					    echo '</a>';
					echo '</div>';
				}else if( isset( $logo__data['logo__mode'] ) &&  $logo__data['logo__mode'] == 'Text' ){

					$logo__data[ $logo__data['logo__mode'] ]['header__alt'] = ( ( isset( $logo__data[ $logo__data['logo__mode'] ]['header__alt'] ) ) ) ? $logo__data[ $logo__data['logo__mode'] ]['header__alt'] : get_bloginfo('name');

						if( isset( $logo__data[ $logo__data['logo__mode'] ]['logo_Text'] ) && strpos( $logo__data[ $logo__data['logo__mode'] ]['logo_Text'],'{%') !== FALSE && strpos( $logo__data[ $logo__data['logo__mode'] ]['logo_Text'],'%}') !== FALSE ){
                            $logo__data[$logo__data['logo__mode']]['logo_Text'] = '<span class="first-logo-word">' . $logo__data[$logo__data['logo__mode']]['logo_Text'] . '</span>';
                            $logo__data[$logo__data['logo__mode']]['logo_Text'] = str_replace('{%', '</span><strong style="color:'.$logo__data[$logo__data['logo__mode']]['secondary_color'].'" class="second-logo-word">', $logo__data[$logo__data['logo__mode']]['logo_Text']);
							$logo__data[ $logo__data['logo__mode'] ]['logo_Text'] = str_replace('%}','</strong>',$logo__data[ $logo__data['logo__mode'] ]['logo_Text']);
						}
						echo '<div class="-site-logo --logo-'.$logo__data['logo__mode'].'">';
							echo'<div class="main-header"></div>';
							echo '<a href="'.home_url().'" title="'.$logo__data[ $logo__data['logo__mode'] ]['header__alt'].'">'.$logo__data[ $logo__data['logo__mode'] ]['logo_Text'].'</a>';
						echo '</div>';
				}
				echo '<div class="--Site--Menu">';
					wp_nav_menu(
				       	array(
							'theme_location' => 'main-menu',
							'menu'           => '',
							'container'      => '',
							'container_class' => '',
							'container_id'   => '',
							'menu_class'     => 'nav navbar-nav menu-master',
							'menu_id'        => '',
							'echo'           => true,
							'fallback_cb'    => 'wp_page_menu',
							'before'         => '',
							'after'          => '',
							'link_before'    => '',
							'link_after'     => '',
							'items_wrap'     => '<ul>%3$s</ul>',
							'depth'          => 0,
							'walker'         => '',
					   	)
					);
					$hide_contact__header = get_option('hide_contact__header');
					if( empty($hide_contact__header) ) 
					$contact_header_list = get_option('contact_header_list');
					if( empty( $hide_contact__header) && !empty($contact_header_list) ){
						$contact_header_list = ( ( is_array( $contact_header_list ) ) ) ? $contact_header_list : array();
						echo '<div class="--company-menu-mobile">';
							echo '<span>روابط المشاركة</span>';	
							echo '<ul class="-company-contact-minibox">';
								$SocialIcons = array(
									'phonenumber'=>'<i class="fa-solid fa-mobile-screen-button"></i>',
									'company__adress'=>'<i class="fa-solid fa-map-location-dot"></i>',
									'whatsapp'=>'<i class="fa-brands fa-whatsapp"></i>',
									'company__mail'=>'<i class="fa-solid fa-envelope"></i>',
								);
								foreach ( $contact_header_list as $social__item ) {
									$social_value = get_option($social__item);
									if( !empty($social_value) ) {
										$URL__value = $social_value;
										$Name__value = $social_value;
										if( $social__item == 'whatsapp_number' ) {
											$URL__value = "https://wa.me/{$social_value}";
											$Name__value = 'تواصل عبر الواتساب ';
											$social__item = 'whatsapp';
										}
										if( $social__item == 'phonenumber' ) {
											$URL__value = "tel:{$social_value}";
											$Name__value = $social_value;
										}
										if( $social__item == 'company__mail' || $social__item == 'company__adress' ) {
											$URL__value = '#';
											$Name__value = $social_value;
										}

										echo '<li class="'.$social__item.'">';
											echo '<a target="_blank" href="'.$URL__value.'"  title="'.$Name__value.'">';
												echo $SocialIcons[ $social__item ];
												echo '<span>'.$Name__value.'</span>';
											echo '</a>';
										echo '</li>';
									}
								}

							echo '<ul>';
						echo '</div>';
						##
					}
				echo '</div>';
				echo '<div class="header--Tools">';

					# SEARCH
					echo '<div class="all-searsh-in">';
						if( empty( $hide_search ) ){
							if( empty( $search_placeholder ) ) $search_placeholder = 'ابحث';
							echo '<div class="--open--searching --search--buttonType-'.$searchButtonType.'" data-button="open-searching" data-searching-argums="'.base64_encode( json_encode( array('Text_search_button'=>$Text_search_button,'search_placeholder'=>$search_placeholder,'search_title'=>$search_title ) ) ).'">'.$Text_search_button.'</div>';
						}
					echo '</div>';

					# CITY
					$hide_city_bar = get_option('hide_city_bar');
					$city = get_option('city_groub');
					if( empty($hide_city_bar) ) {
						if(	isset( $city )  && !empty( $city ) ) {
							echo'<div class="all-taxonimes-in">';
								echo'<div class="-header-call-">';
									echo'<i class="fa-solid fa-phone"></i>';
								echo'</div>';
								echo'<div class="-taxonomy--contact-">';
									foreach ($city as $c => $r) {
										$phonenumber = get_option('number_city');
										$iconss = get_option('city_name');
										echo'<div class="-taxonimes-">';
											echo'<a href="tel:'.$r['number_city'].'" class="tax-in-here">';
												echo'<i class="fa-solid fa-mobile-screen-button"></i>';
												echo'<div class="-cits-taxonimes-">';
													echo'<span class="-city-name-">' .$r['city_name']. '</span>';
													echo'<span class="-city-number-">' .$r['number_city']. '</span>';
												echo'</div>';
											echo'</a>';
										echo'</div>';
									}
									echo'<div class="contact-us-header">';
										echo'<div class="-conatct-text">';
											echo'<i class="fa-regular fa-message-check"></i>';
											echo'<span class="conatct-place">تواصل معنا </span>';
										echo'</div>';
										# SOCIAL 
										echo '<div class="--top-area-social-">';
											if( empty( $hide_social_header ) ) {
												$SocialIcon = array(
													'facebook'=>'<i class="fab fa-facebook-f"></i>',
													'twitter'=>'<i class="fab fa-twitter"></i>',
													'telegram'=>'<i class="fa-brands fa-telegram"></i>',
													'youtube'=>'<i class="fab fa-youtube"></i>',
													'linkedin'=>'<i class="fab fa-linkedin-in"></i>',
													'instagram'=>'<i class="fab fa-instagram"></i>',
												);
												echo '<div class="--socialheader">';
													$SocialIcons = array(
														'phonenumber'=>'<i class="fa-solid fa-mobile-screen-button"></i>',
														'company__adress'=>'<i class="fa-solid fa-map-location-dot"></i>',
														'whatsapp'=>'<i class="fa-brands fa-whatsapp"></i>',
														'company__mail'=>'<i class="fa-solid fa-envelope"></i>',
													);
													echo'<ul class="list-unstyled">';
														foreach ( $social_header_list as $social__item ) {
															$social_value = get_option($social__item);
															if( !empty($social_value) ) {
																echo'<li class="'.$social__item.'"><a class="hoverable" target="_blank" title="'.$social__item.'" href="'.$social_value.'">'.$SocialIcon[ $social__item ].'</a></li>';
															}
														}
													echo'</ul>';
												echo '</div>';
											}
										echo '</div>';
									echo'</div>';
								echo'</div>';
							echo'</div>';
						}
					}

					
					
					

				echo '</div>';
			echo '</div>';
		echo '</div>';
	echo '</header>';
